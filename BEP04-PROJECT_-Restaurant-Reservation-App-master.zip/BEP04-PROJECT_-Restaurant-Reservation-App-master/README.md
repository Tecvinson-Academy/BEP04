This is a simple Restaurant Reservation application built using the Flask framework. The application features a user-friendly interface that allows users to easily make restaurant reservations with minimal effort.

Language: Python 

Framework: Flask 

Database: MariaDB 

Templates Folder (HTML files)  

Static Folder (main.css file)  

Virtual Environment (.venv) 
